let data = [
  {
    id: "1",
    time: "منذ ١٥ دقيقة",
    userName: "مستخدم 1",
    active: false,
  },
  {
    id: "2",
    time: "منذ ١٢ دقيقة",
    userName: "مستخدم 2",
    active: false,
  },
  {
    id: "3",
    time: "منذ ١١ دقيقة",
    userName: "مستخدم 3",
    active: false,
  },
  {
    id: "4",
    time: "منذ ١٠ دقيقة",
    userName: "مالك محمد",
    active: true,
  },
  {
    id: "5",
    time: "منذ ٨ دقيقة",
    userName: "مستخدم 4",
    active: false,
  },
  {
    id: "6",
    time: "منذ ٥ دقيقة",
    userName: "مستخدم 5",
    active: false,
  },
  {
    id: "7",
    time: "منذ ٢ دقيقة",
    userName: "مستخدم 6",
    active: false,
  },
];
export default data;
