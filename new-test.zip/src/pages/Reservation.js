import React from "react";

const Reservation = () => {
  return (
    <div
      className="text-lg w-full justify-center items-center text-white uppercase text-center"
      style={{ minHeight: 700 }}
    >
      Reservation
    </div>
  );
};

export default Reservation;
