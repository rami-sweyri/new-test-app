module.exports = {
  theme: {
    extend: {
      colors: {
        "blue-t-100": "#1f3a6e",
        "blue-t-200": "#254176",
        "blue-t-300": "#1c3668",
      },
    },
  },
  variants: {},
  plugins: [],
};
